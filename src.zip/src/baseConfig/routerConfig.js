import Home from '../home/home.jsx';
import UseNotice from '../useNotice/useNotice.jsx';
import Privacy from '../privacy/privacy.jsx';
import Invoice from '../invoice/invoice.jsx';
import ThemeManage from '../themeManage/themeManage.jsx';

export default [{
    component: Home,
    childs: [{
        path: '/useNotice',
        component: UseNotice
    }, {
        path: '/privacy',
        component: Privacy
    }, {
        path: '/invoice',
        component: Invoice
    }, {
        path: '/themeManage',
        component: ThemeManage
    }]
}];