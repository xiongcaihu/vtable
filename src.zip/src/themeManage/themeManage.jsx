import React from "react";
import { observer } from "mobx-react";
import { observable } from "mobx";
import { Table, Input, Button, Popconfirm, Form, Modal } from "antd";
import "./themeManage.css";
import Mock from "mockjs";

const FormItem = Form.Item;

@observer
class MyModal extends React.Component {
  handleEditSave() {
    let cell = this.props.dataSource[this.props.editingCellIndex];
    this.props.cancelWindow();
  }
  render() {
    let cell = this.props.dataSource[this.props.editingCellIndex];
    return (
      <Modal
        title={this.props.dataSource[this.props.editingCellIndex].title}
        visible={this.props.visible}
        onOk={this.handleEditSave.bind(this)}
        onCancel={() => {
          this.props.cancelWindow();
        }}
      >
        <Form>
          <FormItem label="主题名称">
            {this.props.form.getFieldDecorator("themeName", {
              rules: [
                {
                  required: true,
                  message: "不能为空"
                }
              ],
              initialValue: cell["themeName"]
            })(<Input />)}
          </FormItem>
        </Form>
      </Modal>
    );
  }
}

MyModal = Form.create()(MyModal);

const dataSource = Mock.mock({
  "list|10-100": [
    {
      "key|+1": 0,
      id: "@integer()",
      themeName: "@ctitle()",
      img:
        "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544962465147&di=91a2f0c83ce1ee20733ca0b659a32152&imgtype=0&src=http%3A%2F%2Fpic17.nipic.com%2F20111023%2F8104044_230939695000_2.jpg",
      "state|1": ["shangjia", "xiajia", "zhiding", "zhengchang"],
      editing: false
    }
  ]
}).list;

@observer
class ThemeManage extends React.Component {
  @observable states = {
    tableHeight: 0,
    searchContent: "",
    editingCellIndex: 0,
    editWindowVisible: false
  };

  state = {
    dataSource
  };

  componentWillMount() {
    this.initTable();
  }

  componentDidMount() {
    this.states.tableHeight =
      this.refs.themeManage.offsetHeight - 20 - 31 - 53 - 32 - 32 - 42;
  }

  handleCellEdit(index) {
    this.states.editingCellIndex = index;
    this.states.editWindowVisible = true;
  }

  handleCellEditSave() {
    this.states.editWindowVisible = false;
  }

  handleCellDelete(index) {
    this.state.dataSource.splice(index, 1);
    this.setState({
      dataSource: this.state.dataSource
    });
  }

  defineColumns() {
    // 表头设计
    this.columns = [
      {
        title: "序号",
        render: (text, row, index) => {
          return <span>{index + 1}</span>;
        },
        width: 100,
        align: "center"
      },
      {
        title: "主题名称",
        dataIndex: "themeName",
        editable: true,
        key: "themeName",
        width: 150,
        align: "center",
        sorter: (a, b) => a.state.length - b.state.length,
        filterDropdown: this.filterComponent,
        onFilter: (value, record) => {
          // value 是当前搜索的字符串
          return record.themeName.toLowerCase().includes(value.toLowerCase());
        }
      },
      {
        title: "缩略图",
        dataIndex: "img",
        key: "img",
        align: "center",
        render: (text, row, index) => {
          return <img className="smallImg" src={row.img} />;
        }
      },
      {
        title: "状态",
        dataIndex: "state",
        key: "state",
        align: "center",
        width: 150,
        sorter: (a, b) => a.state.length - b.state.length
      },
      {
        title: "操作",
        width: 150,
        render: (text, record, index) => {
          return (
            <div>
              <span
                style={{ color: "#1890ff", cursor: "pointer", marginRight: 10 }}
                onClick={this.handleCellEdit.bind(this, index)}
              >
                编辑
              </span>
              <span
                style={{ color: "#1890ff", cursor: "pointer" }}
                onClick={this.handleCellDelete.bind(this, index)}
              >
                删除
              </span>
            </div>
          );
        }
      }
    ];
  }

  initTable() {
    this.defineColumns();
  }

  /**
   * 如果当前单元格需要被过滤，那么用此组件
   * @param {} param0
   */
  filterComponent({ setSelectedKeys, selectedKeys, confirm, clearFilters }) {
    return (
      <div className="custom-filter-dropdown">
        <Input
          value={selectedKeys[0]}
          onChange={e =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={e => {
            confirm();
          }}
        />
        <Button
          type="primary"
          onClick={e => {
            confirm();
          }}
        >
          搜索
        </Button>
        <Button onClick={() => clearFilters()}>重置</Button>
      </div>
    );
  }

  addRow() {
    this.state.dataSource.unshift(
      Mock.mock({
        key: Math.random(),
        id: -1,
        themeName: "默认名称",
        img: "",
        state: "xiajia",
        editing: false
      })
    );

    this.setState({
      dataSource: this.state.dataSource.slice()
    });
  }

  render() {
    return (
      <div className="themeManage" ref="themeManage">
        <h2>主题管理</h2>
        <div className="tool">
          <Button onClick={this.addRow.bind(this)}>增加</Button>
          <Button>删除</Button>
          <Button type="primary">保存</Button>
        </div>
        <Table
          bordered
          className="table"
          scroll={{ y: this.states.tableHeight }}
          rowSelection={{}}
          dataSource={this.state.dataSource}
          columns={this.columns}
          pagination={{
            showSizeChanger: true,
            showTotal: total => <span>共 {total} 条</span>
          }}
        />
        <MyModal
          editingCellIndex={this.states.editingCellIndex}
          dataSource={this.state.dataSource}
          visible={this.states.editWindowVisible}
          cancelWindow={() => {
            this.states.editWindowVisible = false;
          }}
        />
      </div>
    );
  }
}

export default ThemeManage;
